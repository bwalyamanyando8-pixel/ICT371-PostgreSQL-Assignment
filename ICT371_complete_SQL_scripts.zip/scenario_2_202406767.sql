-- ICT371 PostgreSQL Scenario Assignment
-- Student: Bwalya Manyando
-- Student Number: 202406767
-- Scenario 2: Computer Laboratory Reservations
-- Questions 1-9

-- QUESTION 1: Create tables and insert at least three lab sessions
CREATE TABLE lab_sessions (
    session_id INTEGER PRIMARY KEY,
    session_name VARCHAR(100) NOT NULL,
    available_workstations INTEGER NOT NULL CHECK (available_workstations >= 0)
);

CREATE TABLE reservations (
    reservation_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    lecturer_name VARCHAR(100) NOT NULL,
    session_id INTEGER NOT NULL REFERENCES lab_sessions(session_id),
    workstations_reserved INTEGER NOT NULL CHECK (workstations_reserved > 0),
    reservation_status VARCHAR(20) NOT NULL DEFAULT 'Reserved'
);

INSERT INTO lab_sessions (session_id, session_name, available_workstations)
VALUES
    (1, 'Database Practical', 30),
    (2, 'Networking Practical', 20),
    (3, 'Programming Practical', 15);

SELECT * FROM lab_sessions ORDER BY session_id;
SELECT * FROM reservations ORDER BY reservation_id;

-- QUESTION 2: IF, ELSIF and ELSE
DO $$
DECLARE
    v_available INTEGER;
BEGIN
    SELECT available_workstations INTO v_available
    FROM lab_sessions WHERE session_id = 1;

    IF v_available = 0 THEN
        RAISE NOTICE 'The lab session is full';
    ELSIF v_available <= 5 THEN
        RAISE NOTICE 'The lab session is nearly full';
    ELSE
        RAISE NOTICE 'The lab session has enough workstations';
    END IF;
END;
$$;

-- QUESTION 3A: WHILE loop - three preparation reminders
DO $$
DECLARE
    v_reminder INTEGER := 1;
BEGIN
    WHILE v_reminder <= 3 LOOP
        RAISE NOTICE 'Session preparation reminder number: %', v_reminder;
        v_reminder := v_reminder + 1;
    END LOOP;
END;
$$;

-- QUESTION 3B: Numeric FOR loop - three workstation checks
DO $$
DECLARE
    v_workstation INTEGER;
BEGIN
    FOR v_workstation IN 1..3 LOOP
        RAISE NOTICE 'Workstation check number: %', v_workstation;
    END LOOP;
END;
$$;

-- QUESTION 4: Create reserve_workstations procedure
CREATE OR REPLACE PROCEDURE reserve_workstations(
    p_lecturer_name VARCHAR(100),
    p_session_id INTEGER,
    p_quantity INTEGER
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_available INTEGER;
BEGIN
    IF p_lecturer_name IS NULL OR TRIM(p_lecturer_name) = '' THEN
        RAISE EXCEPTION 'Lecturer name cannot be blank';
    END IF;

    IF p_quantity IS NULL OR p_quantity <= 0 THEN
        RAISE EXCEPTION 'Workstation quantity must be greater than zero';
    END IF;

    SELECT available_workstations INTO v_available
    FROM lab_sessions
    WHERE session_id = p_session_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Lab session ID % does not exist', p_session_id;
    END IF;

    IF v_available < p_quantity THEN
        RAISE EXCEPTION 'Not enough workstations. Available: %, Requested: %',
            v_available, p_quantity;
    END IF;

    UPDATE lab_sessions
    SET available_workstations = available_workstations - p_quantity
    WHERE session_id = p_session_id;

    INSERT INTO reservations
        (lecturer_name, session_id, workstations_reserved, reservation_status)
    VALUES
        (p_lecturer_name, p_session_id, p_quantity, 'Reserved');

    RAISE NOTICE 'Workstations reserved successfully';
END;
$$;

SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND routine_type = 'PROCEDURE'
  AND routine_name = 'reserve_workstations';

-- QUESTION 5: Test two valid reservations and catch the over-capacity attempt
CALL reserve_workstations('Dr. Banda', 1, 8);
CALL reserve_workstations('Mrs. Phiri', 2, 6);

DO $$
BEGIN
    CALL reserve_workstations('Mr. Zulu', 3, 20);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Expected reservation error handled: %', SQLERRM;
END;
$$;

SELECT * FROM lab_sessions ORDER BY session_id;
SELECT * FROM reservations ORDER BY reservation_id;

-- QUESTION 6: Create cancel_reservation procedure
CREATE OR REPLACE PROCEDURE cancel_reservation(p_reservation_id INTEGER)
LANGUAGE plpgsql
AS $$
DECLARE
    v_session_id INTEGER;
    v_quantity INTEGER;
    v_status VARCHAR(20);
BEGIN
    SELECT session_id, workstations_reserved, reservation_status
    INTO v_session_id, v_quantity, v_status
    FROM reservations
    WHERE reservation_id = p_reservation_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Reservation ID % does not exist', p_reservation_id;
    END IF;

    IF v_status = 'Cancelled' THEN
        RAISE NOTICE 'Reservation % has already been cancelled', p_reservation_id;
        RETURN;
    END IF;

    UPDATE lab_sessions
    SET available_workstations = available_workstations + v_quantity
    WHERE session_id = v_session_id;

    UPDATE reservations
    SET reservation_status = 'Cancelled'
    WHERE reservation_id = p_reservation_id;

    RAISE NOTICE 'Reservation cancelled successfully';
END;
$$;

-- Test cancellation twice to confirm capacity is restored only once
CALL cancel_reservation(1);
CALL cancel_reservation(1);

SELECT * FROM lab_sessions ORDER BY session_id;
SELECT * FROM reservations ORDER BY reservation_id;

-- QUESTION 7: Explicit cursor for sessions with five or fewer workstations
DO $$
DECLARE
    session_cursor CURSOR FOR
        SELECT session_id, session_name, available_workstations
        FROM lab_sessions
        WHERE available_workstations <= 5
        ORDER BY session_id;
    v_session_id INTEGER;
    v_session_name VARCHAR(100);
    v_available INTEGER;
BEGIN
    OPEN session_cursor;
    LOOP
        FETCH session_cursor INTO v_session_id, v_session_name, v_available;
        EXIT WHEN NOT FOUND;
        RAISE NOTICE 'Session ID: %, Session: %, Workstations remaining: %',
            v_session_id, v_session_name, v_available;
    END LOOP;
    CLOSE session_cursor;
END;
$$;

-- QUESTION 8: Handle invalid quantity with an EXCEPTION block
DO $$
BEGIN
    CALL reserve_workstations('Bwalya Manyando', 1, 0);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error handled: %', SQLERRM;
END;
$$;

-- QUESTION 9: Display final tables
SELECT * FROM lab_sessions ORDER BY session_id;
SELECT * FROM reservations ORDER BY reservation_id;
