-- ICT371 PostgreSQL Scenario Assignment
-- Student: Bwalya Manyando
-- Student Number: 202406767
-- Scenario 5: Engineering Workshop Tool Loans
-- Questions 1-9

-- QUESTION 1: Create tables and insert three types of tools
CREATE TABLE tools (
    tool_id INTEGER PRIMARY KEY,
    tool_name VARCHAR(100) NOT NULL,
    available_quantity INTEGER NOT NULL CHECK (available_quantity >= 0)
);

CREATE TABLE tool_loans (
    loan_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    student_number VARCHAR(20) NOT NULL,
    tool_id INTEGER NOT NULL REFERENCES tools(tool_id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    loan_status VARCHAR(20) NOT NULL DEFAULT 'Borrowed'
);

INSERT INTO tools (tool_id, tool_name, available_quantity)
VALUES
    (1, 'Hammer', 10),
    (2, 'Screwdriver', 5),
    (3, 'Spanner', 0);

SELECT * FROM tools ORDER BY tool_id;
SELECT * FROM tool_loans ORDER BY loan_id;

-- QUESTION 2: IF, ELSIF and ELSE
DO $$
DECLARE
    v_quantity INTEGER;
BEGIN
    SELECT available_quantity INTO v_quantity
    FROM tools WHERE tool_id = 1;

    IF v_quantity = 0 THEN
        RAISE NOTICE 'Tool is unavailable';
    ELSIF v_quantity <= 5 THEN
        RAISE NOTICE 'Tool is low on stock: % available', v_quantity;
    ELSE
        RAISE NOTICE 'Tool is readily available: % available', v_quantity;
    END IF;
END;
$$;

-- QUESTION 3A: WHILE loop - three workshop safety reminders
DO $$
DECLARE
    v_reminder INTEGER := 1;
BEGIN
    WHILE v_reminder <= 3 LOOP
        RAISE NOTICE 'Workshop safety reminder number: %', v_reminder;
        v_reminder := v_reminder + 1;
    END LOOP;
END;
$$;

-- QUESTION 3B: Numeric FOR loop - three tool inspections
DO $$
DECLARE
    v_tool_number INTEGER;
BEGIN
    FOR v_tool_number IN 1..3 LOOP
        RAISE NOTICE 'Inspecting workshop tool number: %', v_tool_number;
    END LOOP;
END;
$$;

-- QUESTION 4: Create issue_tool procedure
CREATE OR REPLACE PROCEDURE issue_tool(
    p_student_number VARCHAR(20),
    p_tool_id INTEGER,
    p_quantity INTEGER
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_available INTEGER;
BEGIN
    IF p_student_number IS NULL OR TRIM(p_student_number) = '' THEN
        RAISE EXCEPTION 'Student number cannot be blank';
    END IF;

    IF p_quantity IS NULL OR p_quantity <= 0 THEN
        RAISE EXCEPTION 'Tool quantity must be greater than zero';
    END IF;

    SELECT available_quantity INTO v_available
    FROM tools
    WHERE tool_id = p_tool_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tool ID % does not exist', p_tool_id;
    END IF;

    IF v_available < p_quantity THEN
        RAISE EXCEPTION 'Insufficient stock. Available: %, Requested: %',
            v_available, p_quantity;
    END IF;

    UPDATE tools
    SET available_quantity = available_quantity - p_quantity
    WHERE tool_id = p_tool_id;

    INSERT INTO tool_loans (student_number, tool_id, quantity, loan_status)
    VALUES (p_student_number, p_tool_id, p_quantity, 'Borrowed');

    RAISE NOTICE 'Tool loan recorded successfully';
END;
$$;

SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND routine_type = 'PROCEDURE'
  AND routine_name = 'issue_tool';

-- QUESTION 5: Test two valid loans and catch an over-stock request
CALL issue_tool('202406767', 1, 2);
CALL issue_tool('202400123', 2, 3);

DO $$
BEGIN
    CALL issue_tool('202400456', 3, 2);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Expected tool-issue error handled: %', SQLERRM;
END;
$$;

SELECT * FROM tools ORDER BY tool_id;
SELECT * FROM tool_loans ORDER BY loan_id;

-- QUESTION 6: Create return_tool procedure
CREATE OR REPLACE PROCEDURE return_tool(p_loan_id INTEGER)
LANGUAGE plpgsql
AS $$
DECLARE
    v_tool_id INTEGER;
    v_quantity INTEGER;
    v_status VARCHAR(20);
BEGIN
    SELECT tool_id, quantity, loan_status
    INTO v_tool_id, v_quantity, v_status
    FROM tool_loans
    WHERE loan_id = p_loan_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Loan ID % does not exist', p_loan_id;
    END IF;

    IF v_status = 'Returned' THEN
        RAISE NOTICE 'Loan % has already been returned', p_loan_id;
        RETURN;
    END IF;

    UPDATE tools
    SET available_quantity = available_quantity + v_quantity
    WHERE tool_id = v_tool_id;

    UPDATE tool_loans
    SET loan_status = 'Returned'
    WHERE loan_id = p_loan_id;

    RAISE NOTICE 'Tool returned successfully';
END;
$$;

-- Test returning the same loan twice
CALL return_tool(1);
CALL return_tool(1);

SELECT * FROM tools ORDER BY tool_id;
SELECT * FROM tool_loans ORDER BY loan_id;

-- QUESTION 7: Explicit cursor for tools with three or fewer items available
DO $$
DECLARE
    tool_cursor CURSOR FOR
        SELECT tool_id, tool_name, available_quantity
        FROM tools
        WHERE available_quantity <= 3
        ORDER BY tool_id;
    v_tool_id INTEGER;
    v_tool_name VARCHAR(100);
    v_quantity INTEGER;
BEGIN
    OPEN tool_cursor;
    LOOP
        FETCH tool_cursor INTO v_tool_id, v_tool_name, v_quantity;
        EXIT WHEN NOT FOUND;
        RAISE NOTICE 'Tool ID: %, Tool: %, Quantity remaining: %',
            v_tool_id, v_tool_name, v_quantity;
    END LOOP;
    CLOSE tool_cursor;
END;
$$;

-- QUESTION 8: Handle zero quantity using an EXCEPTION block
DO $$
BEGIN
    CALL issue_tool('202406767', 1, 0);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error handled: %', SQLERRM;
END;
$$;

SELECT * FROM tool_loans ORDER BY loan_id;

-- QUESTION 9: Display final tool quantities and loan statuses
SELECT * FROM tools ORDER BY tool_id;
SELECT * FROM tool_loans ORDER BY loan_id;
