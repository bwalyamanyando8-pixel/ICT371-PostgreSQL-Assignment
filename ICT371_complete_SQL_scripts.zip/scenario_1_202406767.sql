-- ICT371 PostgreSQL Scenario Assignment
-- Student: Bwalya Manyando
-- Student Number: 202406767
-- Scenario 1: University Library Book Loans
-- Questions 1-9

-- QUESTION 1: Create tables and insert at least three books
CREATE TABLE books (
    book_id INTEGER PRIMARY KEY,
    book_title VARCHAR(100) NOT NULL,
    available_copies INTEGER NOT NULL CHECK (available_copies >= 0)
);

CREATE TABLE book_loans (
    loan_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    student_number VARCHAR(20) NOT NULL,
    book_id INTEGER NOT NULL REFERENCES books(book_id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    loan_status VARCHAR(20) NOT NULL DEFAULT 'Borrowed'
);

INSERT INTO books (book_id, book_title, available_copies)
VALUES
    (1, 'Database Systems', 10),
    (2, 'Computer Networks', 5),
    (3, 'Operating Systems', 2);

SELECT * FROM books ORDER BY book_id;
SELECT * FROM book_loans ORDER BY loan_id;

-- QUESTION 2: Use IF, ELSIF and ELSE
DO $$
DECLARE
    v_copies INTEGER;
BEGIN
    SELECT available_copies INTO v_copies
    FROM books
    WHERE book_id = 1;

    IF v_copies = 0 THEN
        RAISE NOTICE 'Book is unavailable';
    ELSIF v_copies <= 3 THEN
        RAISE NOTICE 'Book is low on copies';
    ELSE
        RAISE NOTICE 'Book is sufficiently stocked';
    END IF;
END;
$$;

-- QUESTION 3A: WHILE loop - three overdue reminders
DO $$
DECLARE
    v_reminder INTEGER := 1;
BEGIN
    WHILE v_reminder <= 3 LOOP
        RAISE NOTICE 'Overdue reminder number: %', v_reminder;
        v_reminder := v_reminder + 1;
    END LOOP;
END;
$$;

-- QUESTION 3B: Numeric FOR loop - three library shelves
DO $$
DECLARE
    v_shelf INTEGER;
BEGIN
    FOR v_shelf IN 1..3 LOOP
        RAISE NOTICE 'Library shelf number: %', v_shelf;
    END LOOP;
END;
$$;

-- QUESTION 4: Create borrow_book procedure
CREATE OR REPLACE PROCEDURE borrow_book(
    p_student_number VARCHAR(20),
    p_book_id INTEGER,
    p_quantity INTEGER
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_available INTEGER;
BEGIN
    IF p_student_number IS NULL OR TRIM(p_student_number) = '' THEN
        RAISE EXCEPTION 'Student number cannot be blank';
    END IF;

    IF p_quantity IS NULL OR p_quantity <= 0 THEN
        RAISE EXCEPTION 'Quantity must be greater than zero';
    END IF;

    SELECT available_copies INTO v_available
    FROM books
    WHERE book_id = p_book_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Book ID % does not exist', p_book_id;
    END IF;

    IF v_available < p_quantity THEN
        RAISE EXCEPTION 'Not enough copies. Available: %, Requested: %',
            v_available, p_quantity;
    END IF;

    UPDATE books
    SET available_copies = available_copies - p_quantity
    WHERE book_id = p_book_id;

    INSERT INTO book_loans (student_number, book_id, quantity, loan_status)
    VALUES (p_student_number, p_book_id, p_quantity, 'Borrowed');

    RAISE NOTICE 'Book borrowed successfully';
END;
$$;

SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND routine_type = 'PROCEDURE'
  AND routine_name = 'borrow_book';

-- QUESTION 5: Test borrow_book (the over-stock test is caught so the script continues)
CALL borrow_book('202406767', 1, 2);
CALL borrow_book('202400123', 2, 3);

DO $$
BEGIN
    CALL borrow_book('202400456', 3, 5);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Expected borrowing error handled: %', SQLERRM;
END;
$$;

SELECT * FROM books ORDER BY book_id;
SELECT * FROM book_loans ORDER BY loan_id;

-- QUESTION 6: Create return_book procedure
CREATE OR REPLACE PROCEDURE return_book(p_loan_id INTEGER)
LANGUAGE plpgsql
AS $$
DECLARE
    v_book_id INTEGER;
    v_quantity INTEGER;
    v_status VARCHAR(20);
BEGIN
    SELECT book_id, quantity, loan_status
    INTO v_book_id, v_quantity, v_status
    FROM book_loans
    WHERE loan_id = p_loan_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Loan ID % does not exist', p_loan_id;
    END IF;

    IF v_status = 'Returned' THEN
        RAISE NOTICE 'Loan % has already been returned', p_loan_id;
        RETURN;
    END IF;

    UPDATE books
    SET available_copies = available_copies + v_quantity
    WHERE book_id = v_book_id;

    UPDATE book_loans
    SET loan_status = 'Returned'
    WHERE loan_id = p_loan_id;

    RAISE NOTICE 'Book returned successfully';
END;
$$;

-- Test return twice; the second call must not restore copies again
CALL return_book(1);
CALL return_book(1);

SELECT * FROM books ORDER BY book_id;
SELECT * FROM book_loans ORDER BY loan_id;

-- QUESTION 7: Explicit cursor for books with low availability
DO $$
DECLARE
    book_cursor CURSOR FOR
        SELECT book_id, book_title, available_copies
        FROM books
        WHERE available_copies <= 3
        ORDER BY book_id;
    v_book_id INTEGER;
    v_book_title VARCHAR(100);
    v_available INTEGER;
BEGIN
    OPEN book_cursor;
    LOOP
        FETCH book_cursor INTO v_book_id, v_book_title, v_available;
        EXIT WHEN NOT FOUND;
        RAISE NOTICE 'Book ID: %, Title: %, Copies remaining: %',
            v_book_id, v_book_title, v_available;
    END LOOP;
    CLOSE book_cursor;
END;
$$;

-- QUESTION 8: Handle invalid quantity with an EXCEPTION block
DO $$
BEGIN
    CALL borrow_book('202406767', 1, 0);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error handled: %', SQLERRM;
END;
$$;

-- QUESTION 9: Display final results
SELECT book_id, book_title, available_copies
FROM books
ORDER BY book_id;

SELECT loan_id, student_number, book_id, quantity, loan_status
FROM book_loans
ORDER BY loan_id;
