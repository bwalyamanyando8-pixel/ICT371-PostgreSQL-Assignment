-- ICT371 PostgreSQL Scenario Assignment
-- Student: Bwalya Manyando
-- Student Number: 202406767
-- Scenario 3: Student Hostel Room Allocation
-- Questions 1-9

-- QUESTION 1: Create tables and insert three hostel rooms
CREATE TABLE hostel_rooms (
    room_id INTEGER PRIMARY KEY,
    room_name VARCHAR(50) NOT NULL,
    available_beds INTEGER NOT NULL CHECK (available_beds >= 0)
);

CREATE TABLE allocations (
    allocation_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    student_number VARCHAR(20) NOT NULL,
    room_id INTEGER NOT NULL REFERENCES hostel_rooms(room_id),
    allocation_status VARCHAR(20) NOT NULL DEFAULT 'Allocated'
);

INSERT INTO hostel_rooms (room_id, room_name, available_beds)
VALUES
    (1, 'Hostel A - Room 101', 4),
    (2, 'Hostel A - Room 102', 1),
    (3, 'Hostel B - Room 201', 0);

SELECT * FROM hostel_rooms ORDER BY room_id;
SELECT * FROM allocations ORDER BY allocation_id;

-- QUESTION 2: IF, ELSIF and ELSE
DO $$
DECLARE
    v_available INTEGER;
BEGIN
    SELECT available_beds INTO v_available
    FROM hostel_rooms WHERE room_id = 1;

    IF v_available = 0 THEN
        RAISE NOTICE 'The room is full';
    ELSIF v_available = 1 THEN
        RAISE NOTICE 'Only one bed space is available';
    ELSE
        RAISE NOTICE 'Several bed spaces are available: %', v_available;
    END IF;
END;
$$;

-- QUESTION 3A: WHILE loop - three hostel inspection days
DO $$
DECLARE
    v_day INTEGER := 1;
BEGIN
    WHILE v_day <= 3 LOOP
        RAISE NOTICE 'Hostel inspection day: %', v_day;
        v_day := v_day + 1;
    END LOOP;
END;
$$;

-- QUESTION 3B: Numeric FOR loop - inspect three rooms
DO $$
DECLARE
    v_room_id INTEGER;
BEGIN
    FOR v_room_id IN 1..3 LOOP
        RAISE NOTICE 'Inspecting hostel room number: %', v_room_id;
    END LOOP;
END;
$$;

-- QUESTION 4: Create allocate_room procedure
CREATE OR REPLACE PROCEDURE allocate_room(
    p_student_number VARCHAR(20),
    p_room_id INTEGER
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_available_beds INTEGER;
BEGIN
    IF p_student_number IS NULL OR TRIM(p_student_number) = '' THEN
        RAISE EXCEPTION 'Student number cannot be blank';
    END IF;

    SELECT available_beds INTO v_available_beds
    FROM hostel_rooms
    WHERE room_id = p_room_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Room ID % does not exist', p_room_id;
    END IF;

    IF v_available_beds <= 0 THEN
        RAISE EXCEPTION 'Room % is full', p_room_id;
    END IF;

    UPDATE hostel_rooms
    SET available_beds = available_beds - 1
    WHERE room_id = p_room_id;

    INSERT INTO allocations (student_number, room_id, allocation_status)
    VALUES (p_student_number, p_room_id, 'Allocated');

    RAISE NOTICE 'Room % allocated successfully to student %',
        p_room_id, p_student_number;
END;
$$;

SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND routine_type = 'PROCEDURE'
  AND routine_name = 'allocate_room';

-- QUESTION 5: Test two successful allocations and catch full-room attempt
CALL allocate_room('202406767', 1);
CALL allocate_room('202400123', 2);

DO $$
BEGIN
    CALL allocate_room('202400456', 3);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Expected allocation error handled: %', SQLERRM;
END;
$$;

SELECT * FROM hostel_rooms ORDER BY room_id;
SELECT * FROM allocations ORDER BY allocation_id;

-- QUESTION 6: Create check_out procedure
CREATE OR REPLACE PROCEDURE check_out(p_allocation_id INTEGER)
LANGUAGE plpgsql
AS $$
DECLARE
    v_room_id INTEGER;
    v_status VARCHAR(20);
BEGIN
    SELECT room_id, allocation_status
    INTO v_room_id, v_status
    FROM allocations
    WHERE allocation_id = p_allocation_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Allocation ID % does not exist', p_allocation_id;
    END IF;

    IF v_status = 'Checked Out' THEN
        RAISE NOTICE 'Allocation % has already been checked out', p_allocation_id;
        RETURN;
    END IF;

    UPDATE hostel_rooms
    SET available_beds = available_beds + 1
    WHERE room_id = v_room_id;

    UPDATE allocations
    SET allocation_status = 'Checked Out'
    WHERE allocation_id = p_allocation_id;

    RAISE NOTICE 'Student checked out successfully';
END;
$$;

-- Test checkout twice; the second call must not restore a bed again
CALL check_out(1);
CALL check_out(1);

SELECT * FROM hostel_rooms ORDER BY room_id;
SELECT * FROM allocations ORDER BY allocation_id;

-- QUESTION 7: Explicit cursor for rooms with one or fewer beds available
DO $$
DECLARE
    room_cursor CURSOR FOR
        SELECT room_id, room_name, available_beds
        FROM hostel_rooms
        WHERE available_beds <= 1
        ORDER BY room_id;
    v_room_id INTEGER;
    v_room_name VARCHAR(50);
    v_available_beds INTEGER;
BEGIN
    OPEN room_cursor;
    LOOP
        FETCH room_cursor INTO v_room_id, v_room_name, v_available_beds;
        EXIT WHEN NOT FOUND;
        RAISE NOTICE 'Room ID: %, Room: %, Available beds: %',
            v_room_id, v_room_name, v_available_beds;
    END LOOP;
    CLOSE room_cursor;
END;
$$;

-- QUESTION 8: Handle blank student number with an EXCEPTION block
DO $$
BEGIN
    CALL allocate_room(' ', 1);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error handled: %', SQLERRM;
END;
$$;

SELECT * FROM allocations ORDER BY allocation_id;

-- QUESTION 9: Display final tables
SELECT * FROM hostel_rooms ORDER BY room_id;
SELECT * FROM allocations ORDER BY allocation_id;
